import arbol from './arbol.png';
import gato from './gato.png';
import luna from './luna.png';
import perro from './perro.png';
import sol from './sol.png';

export default {
    "arbol": arbol,
    "gato": gato,
    "luna": luna,
    "perro": perro,
    "sol": sol
}