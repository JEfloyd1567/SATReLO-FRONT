

export const AllPatientsHeader = () => {
  return (
    <>
      <a href="/MisPacientes">Ver mis pacientes</a>
    </>
  )
}
