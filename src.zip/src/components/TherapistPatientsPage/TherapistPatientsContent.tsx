import { faCircleUser } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"


export const TherapistPatientsContent = () => {

  return (
    <div className="row row-cols-3 gy-4">
      <div className="col d-flex justify-content-center">
        <div className="border shadow rounded-3 px-5 py-3 d-inline-flex flex-column align-items-center" >
          <FontAwesomeIcon icon={faCircleUser} className='text-primary mb-3' size="7x" />
          <p className="fw-bold align-bottom">Nombre Paciente</p>
          <p>Desde: DD/MM/YYYY</p>
          <a href='#' >Ver Perfil</a>
        </div>
      </div>

      <div className="col d-flex justify-content-center">
        <div className="border shadow rounded-3 px-5 py-3 d-inline-flex flex-column align-items-center" >
          <FontAwesomeIcon icon={faCircleUser} className='text-primary mb-3' size="7x" />
          <p className="fw-bold align-bottom">Nombre Paciente</p>
          <p>Desde: DD/MM/YYYY</p>
          <a href='#' >Ver Perfil</a>
        </div>
      </div>

      <div className="col d-flex justify-content-center">
        <div className="border shadow rounded-3 px-5 py-3 d-inline-flex flex-column align-items-center" >
          <FontAwesomeIcon icon={faCircleUser} className='text-primary mb-3' size="7x" />
          <p className="fw-bold align-bottom">Nombre Paciente</p>
          <p>Desde: DD/MM/YYYY</p>
          <a href='#' >Ver Perfil</a>
        </div>
      </div>

      <div className="col d-flex justify-content-center">
        <div className="border shadow rounded-3 px-5 py-3 d-inline-flex flex-column align-items-center" >
          <FontAwesomeIcon icon={faCircleUser} className='text-primary mb-3' size="7x" />
          <p className="fw-bold align-bottom">Nombre Paciente</p>
          <p>Desde: DD/MM/YYYY</p>
          <a href='#' >Ver Perfil</a>
        </div>
      </div>
    </div>
  )
}
