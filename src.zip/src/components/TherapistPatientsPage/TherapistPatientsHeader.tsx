import { FC } from "react";
import { SearchBox } from "../SearchBox/SearchBox"

interface Props {
  title: string;
}

export const TherapistPatientsHeader: FC<Props> = ({title}) => {

  return (
    <>
      <div className="d-flex flex-column w-100">
        <div className="d-flex justify-content-between align-items-center">
          <h2 className="fw-bold">{title}</h2>
          <a href="/TodosLosPacientes">Todos Los Pacientes</a>
        </div>

        <div className="d-flex flex-row justify-content-end align-items-center" style={{height: '80px'}}>
          <SearchBox />
        </div>
      </div>
    </>
  )
}
