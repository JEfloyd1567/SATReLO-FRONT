import { FC } from "react";
import { Toast } from "react-bootstrap"

interface Props {
  msg: string;
  handleCloseBtnClick: () => void;
}

export const ErrorToast: FC<Props> = ({msg ,handleCloseBtnClick}) => {
  return (
    <div className="col col-12 d-flex align-items-center rounded justify-content-between shadow bg-danger mb-4 py-2" style={{maxWidth: '410px'}}>
      <p className="m-0 text-white toast-body">{msg}</p>
      <button type="button" className="btn-close btn-close-white" onClick={() => handleCloseBtnClick()}></button>
    </div>
    // <Toast show={true} bg='danger' style={{color:"white", maxWidth: '410px'}} className='d-inline-block w-100 mx-3'>
    //     <Toast.Body className="d-flex justify-content-between">
    //         {msg}
    //         <button type="button" className="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close" onClick={() => handleCloseBtnClick()} ></button>
    //     </Toast.Body>
    // </Toast>
  )
}
