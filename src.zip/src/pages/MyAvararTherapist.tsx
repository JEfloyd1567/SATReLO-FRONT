import { MyAvatar } from "../components/MyAvatarTherapist/MyAvatar";

export const MyAvatarTherapist = () => {
    return(
        <MyAvatar/>
    );
};