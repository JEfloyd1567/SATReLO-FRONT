import { SearchBox, TherapistLayout, TherapistPatientsContent, TherapistPatientsHeader} from "../components";
import { TherapistPatientsFooter } from "../components/TherapistPatientsPage/TherapistPatientsFooter";


export const TherapistPage = () => {
    return(
      <TherapistLayout
        header={<TherapistPatientsHeader title="Mis Pacientes" />}
        footer={<TherapistPatientsFooter />}
      >
      
      <TherapistPatientsContent />

    </TherapistLayout>
    );
};