import { TherapistProfile } from "../components/TherapistProfile/TherapistProfile";

export const TherapistProfilePage = () => {
    return(
        <TherapistProfile/>
    );
};